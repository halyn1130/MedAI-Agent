# 시장 평가용 기존 데이터셋

PDF 원본과 metadata.csv는 data/market_rag/ 아래에 있습니다.
dataset.json은 공통 Worker 입력의 dataset 값으로 사용할 수 있습니다.
Orchestrator에서 기업 평가에 필요한 records를 준비하여 전달하세요.
시장 Worker는 PDF/인덱스를 읽거나 외부 검색·수집을 수행하지 않습니다.
checked_at=null은 기존 메타데이터에 확인일이 없음을 뜻합니다.
이번 내보내기에서는 자료를 다시 수집하지 않았습니다.
